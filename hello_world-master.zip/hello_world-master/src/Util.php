<?php
namespace abinmt\helloWorld;

class Util
{

    function sayHello() 
    {
        echo "HelloWorld";
    }
}